package android.arch.a.a;

public abstract class c {
    public abstract void a(Runnable runnable);

    public abstract void b(Runnable runnable);

    public abstract boolean b();
}
