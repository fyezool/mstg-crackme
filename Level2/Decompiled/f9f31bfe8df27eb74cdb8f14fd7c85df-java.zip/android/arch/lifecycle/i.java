package android.arch.lifecycle;

import java.util.HashMap;
import java.util.Map;

public class i {
    private Map<String, Integer> a = new HashMap();
}
