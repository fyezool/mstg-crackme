package android.arch.lifecycle;

public interface k<T> {
    void a(T t);
}
