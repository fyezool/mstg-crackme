package android.arch.lifecycle;

import android.arch.lifecycle.c;

public interface GenericLifecycleObserver extends d {
    void a(e eVar, c.a aVar);
}
