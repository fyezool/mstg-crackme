package android.arch.lifecycle;

public interface e {
    c a();
}
