package android.arch.lifecycle;

public class j<T> extends LiveData<T> {
}
