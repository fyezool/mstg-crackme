package android.arch.lifecycle;

import android.arch.lifecycle.c;

public class SingleGeneratedAdapterObserver implements GenericLifecycleObserver {
    private final b a;

    SingleGeneratedAdapterObserver(b bVar) {
        this.a = bVar;
    }

    public void a(e eVar, c.a aVar) {
        this.a.a(eVar, aVar, false, (i) null);
        this.a.a(eVar, aVar, true, (i) null);
    }
}
