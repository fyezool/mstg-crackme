package android.arch.lifecycle;

public class o {

    public interface a {
    }
}
