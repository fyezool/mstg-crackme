package android.support.a;

import owasp.mstg.uncrackable2.R;

public final class a {

    /* renamed from: android.support.a.a$a  reason: collision with other inner class name */
    public static final class C0002a {
        public static final int action_container = 2131165197;
        public static final int action_divider = 2131165199;
        public static final int action_image = 2131165200;
        public static final int action_text = 2131165206;
        public static final int actions = 2131165207;
        public static final int async = 2131165213;
        public static final int blocking = 2131165216;
        public static final int chronometer = 2131165224;
        public static final int forever = 2131165244;
        public static final int icon = 2131165248;
        public static final int icon_group = 2131165249;
        public static final int info = 2131165252;
        public static final int italic = 2131165254;
        public static final int line1 = 2131165256;
        public static final int line3 = 2131165257;
        public static final int normal = 2131165265;
        public static final int notification_background = 2131165266;
        public static final int notification_main_column = 2131165267;
        public static final int notification_main_column_container = 2131165268;
        public static final int right_icon = 2131165277;
        public static final int right_side = 2131165278;
        public static final int tag_transition_group = 2131165310;
        public static final int text = 2131165311;
        public static final int text2 = 2131165312;
        public static final int time = 2131165315;
        public static final int title = 2131165316;
    }

    public static final class b {
        public static final int[] FontFamily = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, R.attr.font, R.attr.fontStyle, R.attr.fontWeight};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_font = 3;
        public static final int FontFamilyFont_fontStyle = 4;
        public static final int FontFamilyFont_fontWeight = 5;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
    }
}
