package android.support.v4.g;

import android.view.View;

public interface v {
    void a(View view);
}
