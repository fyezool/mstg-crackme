package android.support.v4.g;

public interface h {
    void stopNestedScroll();
}
