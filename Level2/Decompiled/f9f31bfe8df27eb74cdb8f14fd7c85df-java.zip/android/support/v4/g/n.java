package android.support.v4.g;

import android.view.View;

public interface n {
    w a(View view, w wVar);
}
