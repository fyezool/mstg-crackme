package android.support.v4.g;

import android.view.View;

public interface l extends k {
    void a(View view, int i);

    void a(View view, int i, int i2, int i3, int i4, int i5);

    void a(View view, int i, int i2, int[] iArr, int i3);

    boolean a(View view, View view2, int i, int i2);

    void b(View view, View view2, int i, int i2);
}
