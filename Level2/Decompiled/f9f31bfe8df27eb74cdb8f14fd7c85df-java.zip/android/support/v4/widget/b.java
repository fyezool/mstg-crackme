package android.support.v4.widget;

import android.support.v4.d.a;

public interface b {
    public static final boolean a = a.a();
}
