package android.support.v4.d;

import android.os.Build;

public class a {
    @Deprecated
    public static boolean a() {
        return Build.VERSION.SDK_INT >= 27;
    }
}
