package android.support.v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public abstract class i {
    public g a(Context context, String str, Bundle bundle) {
        return g.a(context, str, bundle);
    }

    public abstract View a(int i);

    public abstract boolean a();
}
