package android.support.v4.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class l {

    public static abstract class a {
        public void a(l lVar, g gVar) {
        }

        public void a(l lVar, g gVar, Context context) {
        }

        public void a(l lVar, g gVar, Bundle bundle) {
        }

        public void a(l lVar, g gVar, View view, Bundle bundle) {
        }

        public void b(l lVar, g gVar) {
        }

        public void b(l lVar, g gVar, Context context) {
        }

        public void b(l lVar, g gVar, Bundle bundle) {
        }

        public void c(l lVar, g gVar) {
        }

        public void c(l lVar, g gVar, Bundle bundle) {
        }

        public void d(l lVar, g gVar) {
        }

        public void d(l lVar, g gVar, Bundle bundle) {
        }

        public void e(l lVar, g gVar) {
        }

        public void f(l lVar, g gVar) {
        }

        public void g(l lVar, g gVar) {
        }
    }

    public interface b {
        void a();
    }

    public abstract void a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract boolean a();

    public abstract List<g> b();

    public abstract boolean c();
}
