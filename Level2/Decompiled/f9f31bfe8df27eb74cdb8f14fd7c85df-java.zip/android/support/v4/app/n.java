package android.support.v4.app;

import android.arch.lifecycle.p;
import java.util.List;

public class n {
    private final List<g> a;
    private final List<n> b;
    private final List<p> c;

    n(List<g> list, List<n> list2, List<p> list3) {
        this.a = list;
        this.b = list2;
        this.c = list3;
    }

    /* access modifiers changed from: package-private */
    public List<g> a() {
        return this.a;
    }

    /* access modifiers changed from: package-private */
    public List<n> b() {
        return this.b;
    }

    /* access modifiers changed from: package-private */
    public List<p> c() {
        return this.c;
    }
}
