package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class y extends AndroidRuntimeException {
    public y(String str) {
        super(str);
    }
}
