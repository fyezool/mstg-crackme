package android.support.v7.widget;

public interface bd {
    CharSequence a();
}
