package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

class au {
    public ColorStateList a;
    public PorterDuff.Mode b;
    public boolean c;
    public boolean d;

    au() {
    }

    /* access modifiers changed from: package-private */
    public void a() {
        this.a = null;
        this.d = false;
        this.b = null;
        this.c = false;
    }
}
