package android.support.v7.widget;

import android.content.res.Resources;
import android.widget.SpinnerAdapter;

public interface as extends SpinnerAdapter {
    Resources.Theme a();

    void a(Resources.Theme theme);
}
