package android.support.v7.widget;

import android.support.v7.view.menu.o;
import android.view.Menu;
import android.view.Window;

public interface ad {
    void a(int i);

    void a(Menu menu, o.a aVar);

    boolean e();

    boolean f();

    boolean g();

    boolean h();

    boolean i();

    void j();

    void k();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
