package android.support.v7.view.menu;

import android.content.Context;

public interface o {

    public interface a {
        void a(h hVar, boolean z);

        boolean a(h hVar);
    }

    void a(Context context, h hVar);

    void a(h hVar, boolean z);

    void a(a aVar);

    boolean a(h hVar, j jVar);

    boolean a(u uVar);

    void b(boolean z);

    boolean b();

    boolean b(h hVar, j jVar);
}
