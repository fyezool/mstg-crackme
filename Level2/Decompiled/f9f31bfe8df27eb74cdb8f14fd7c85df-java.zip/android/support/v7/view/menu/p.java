package android.support.v7.view.menu;

public interface p {

    public interface a {
        void a(j jVar, int i);

        boolean a();

        j getItemData();
    }

    void a(h hVar);
}
