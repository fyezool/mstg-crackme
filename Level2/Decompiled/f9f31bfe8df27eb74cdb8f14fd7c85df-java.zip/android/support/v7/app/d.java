package android.support.v7.app;

import android.support.v7.view.b;

public interface d {
    b a(b.a aVar);

    void a(b bVar);

    void b(b bVar);
}
